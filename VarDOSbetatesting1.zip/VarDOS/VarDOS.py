import os, getpass, platform, time

os.system("clear")

print("")
print("Welcome to VAR-DOS, my very own operating system. To get started, you can type '?' or 'help' for a list of commands.")
print("")

name = getpass.getuser()
hostname = platform.node()
processor = platform.machine()

start = time.time()
def uptime():
    elapsed = time.time() - start
    return int(elapsed)

while True:
    terminal = input(f"{name}@VAR-DOS ~ %: ")
    if terminal == "neofetch":
        print(f"___          ___     {name}@{hostname}")
        print(f"\  \        /  /     ---------------------------------")
        print(f" \  \      /  /      ")
        print(f"  \  \    /  /       OS: Var-DOS V0.1 ")
        print(f"  _\  \ _/__/__      Host: {hostname}")
        print(f"  | \  \_____  \     Kernel: python")
        print(f"  |  \____/  \  \    Uptime: {uptime()} seconds")
        print(f"  |  |       |  |    Author: dvd.iso")
        print(f"  |  | ______|__|    Shell: VDS")
        print(f"  |  /________   \   Terminal: VDS")
        print(f"  |___________\___\  Terminal Font: Cascade Mono") 
        print(f"    \   \________    CPU: NaN")
        print(f"     \________   \   GPU: NaN")
        print(f"      ___     \   \  Memory: NaN")
        print(f"     \   \____/   /  ")
        print(f"      \__________/   ---------------------------------")
        print("")

    elif terminal == "clear":
        os.system("clear")
        print("")
        print("Welcome to VAR-DOS, my very own operating system. To get started, you can type '?' or 'help' for a list of commands.")
        print("")   

    elif terminal == "help" or terminal == "?":
        print("")
        print("---------------------------------")
        print("            Commands             ")
        print(" neofetch - Shows OS info.")
        print(" osdir - Shows directory of OS.")
        print(" clear - Clears the terminal.")
        print(" say - Says something in TTS.")
        print(" fs - 'ls' but limited.")
        print(" logo - Neofetch logo.")
        print(" apps - Shows installed apps.")
        print(" appinfo - Info about apps.")
        print(" run - Runs an application.")
        print("")
        print("---------------------------------")
        print("")

    elif terminal == "osdir":
        print(os.getcwd())
    
    elif terminal == "say":
        speech = input("SPEECH: ")
        os.system(f"say {speech}")

    elif terminal == "fs":
        print(os.system("ls"))

    elif terminal == "logo":
        print("___          ___     ")
        print("\  \        /  /     ")
        print(" \  \      /  /      ")
        print("  \  \    /  /       ")
        print("  _\  \ _/__/__      ")
        print("  | \  \_____  \     ")
        print("  |  \____/  \  \    ")
        print("  |  |       |  |    ")
        print("  |  | ______|__|    ")
        print("  |  /________   \   ")
        print("  |___________\___\  ") 
        print("    \   \________    ")
        print("     \________   \   ")
        print("      ___     \   \  ")
        print("     \   \____/   /  ")
        print("      \__________/   ")
        print("")

    elif terminal == "apps":
        print("")
        print("---------------------------------")
        print("               Apps              ")
        print(" FlipACoin.xcec")
        print("")
        print("---------------------------------")
        print("")

    elif terminal == "appinfo":
        print("")
        print("---------------------------------")
        print("             Appinfo             ")
        print(" To run VDS apps, simply type the")
        print(" 'run' command. Example: ")
        print(" run flipacoin.xcec")
        print("")
        print("---------------------------------")
        print("")

    elif terminal == "run flipacoin.xcec" or terminal == "run flipacoin":
        print(os.system("python3 APPFlipACoin.py"))




    else:
        print(f"VDS: command not found: {terminal}")